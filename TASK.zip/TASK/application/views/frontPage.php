<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular-route.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/pnotify/3.2.1/pnotify.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/pnotify/3.2.1/pnotify.brighttheme.css" rel="stylesheet">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/pnotify/3.2.1/pnotify.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pnotify/3.2.1/pnotify.buttons.js"></script>
    <link rel="stylesheet" href="<?= base_url("assets/css/Rgstr.css") ?>">
</head>

<body ng-app="crudApp" ng-controller="crudController">

    <!-- search bar -->
    <div class="d-flex justify-content-center align-items-center" style="width: 450px; margin-left: 500px; margin-top:3%">
        <div class="input-group input-group-sm mb-3">
            <input type="search" id="search-input" class="form-control" ng-model="searchQuery" placeholder="Search By Name.." aria-label="Search" aria-describedby="search-button" ng-keyup="$event.keyCode == 13 ? search() : null">
            <button id="search-button" class="btn btn-primary" type="button" value="search" ng-click="search()">
                Search
            </button>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal">Create New</button>


        </div>
    </div>

    <!-- Add Modal -->
    <div id="addModal" class="modal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Record</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form ng-submit="createRecord()">
                        <div class="form-group">
                            <input type="hidden" id="id" ng-model="id">
                        </div>
                        <div class="form-group">
                            <label for="name">Name:</label>
                            <input type="text" class="form-control" id="name" ng-model="name" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" class="form-control" id="email" ng-model="email" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Add</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- edit model -->
    <div id="editModal" class="modal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Record</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form ng-submit="updateRecord()">
                        <div class="form-group">
                            <!-- this is place where i have changed if any prolem occures then
                            uncomment this -->
                            <!-- <input type="hidden" id="id" ng-model="id"> -->
                        </div>
                        <div class="form-group">
                            <label for="name">Name:</label>
                            <input type="text" class="form-control" id="name" ng-model="editedName" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" class="form-control" id="email" ng-model="editedEmail" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>



    <button type="button" class="btn btn-danger" ng-click="deleteSelected()" ng-show="showDeleteButton"><i class="fa fa-trash-o" style="font-size:15px"></i></button>

    <h2>All Records</h2>
    <div ng-if="filteredData.length==0">No Record Found</div>
    <table>
        <thead>
            <tr>
                <th><input type="checkbox" ng-model="selectAll" ng-click="toggleAll()"></th>
                <th class="sortable" ng-click="sortBy('id')">ID
                    <span ng-if="sortKey=='id' && !reverse">&#9650;</span>
                    <span ng-if="sortKey=='id' && reverse">&#9660;</span>
                </th>
                <th class="sortable" ng-click="sortBy('name')">Name
                    <span ng-if="sortKey=='name' && !reverse">&#9650;</span>
                    <span ng-if="sortKey=='name' && reverse">&#9660;</span>
                </th>
                <th class="sortable" ng-click="sortBy('email')">Email
                    <span ng-if="sortKey=='email' && !reverse">&#9650;</span>
                    <span ng-if="sortKey=='email' && reverse">&#9660;</span>
                </th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <tr ng-repeat="record in (searchButtonClicked ? filteredData : submittedData | orderBy:sortKey:reverse)">
                <td><input type="checkbox" ng-model="record.checked"></td>
                <td>{{ record.id }}</td>
                <td>{{ record.name }}</td>
                <td>{{ record.email }}</td>
                <td>
                    <button ng-click="openEditModal(record)">Edit</button>
                    <button ng-click="downloadCSV(record.id)"><i class="fa fa-download" style="font-size:20px"></i></button>
                    <button ng-click="deleteRecord(record)" class="btn btn-danger"><i class="fa fa-trash-o" style="font-size:24px"></i></button>
                </td>
            </tr>
        </tbody>
    </table>
    <br><br>

    <!-- pagination code -->
    <ul class="pagination justify-content-center">
        <li class="page-item" ng-class="{disabled: currentPage == 1}">
            <a class="page-link" href="#" aria-label="Previous" ng-click="setPage(currentPage - 1)">
                <span aria-hidden="true">&laquo; Previous</span>
            </a>
        </li>
        <li class="page-item">
            <div class="d-flex justify-content-center mt-3">
                <div class="input-group">
                    <input type="text" min="1" max="{{ totalPages }}" class="form-control page-input" ng-model="currentPage" ng-keyup="$event.keyCode == 13 ? goToPageFn() : null" style="width:40px; margin-top:-15px">
                </div>
            </div>
        </li>
        <li class="page-item" ng-class="{disabled: currentPage == totalPages || currentPage > totalPages}">
            <a class="page-link" href="#" aria-label="Next" ng-click="setPage(currentPage + 1)">
                <span aria-hidden="true">Next &raquo;</span>
            </a>
        </li>
    </ul>




    <!-- delete confirmation popup code -->
    <div class="modal new-folder-modal fade" id="deleteFolderModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body p-15 p-md30">
                    <p>Are You Sure?</p>
                    <div class="mt10 description">
                        Do you really want to delete this Record?
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="theme-btn-white" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="theme-btn-blue yes">Delete</button>
                </div>
            </div>
        </div>
    </div>



    <script>
        var app = angular.module('crudApp', []);
        var $config = {
            'base_url': '<?php echo $this->config->item("base_url") ?>'
        }
        app.controller('crudController', ['$scope', '$http', function($scope, $http) {
            $scope.submittedData = [];
            $scope.editedName = '';
            $scope.editedEmail = '';
            $scope.editIndex = -1;
            $scope.searchButtonClicked = false;
            $scope.totalPages = 1;
            $scope.currentPage = 1;
            $scope.recordsPerPage = 4;
            $scope.itemsPerPage = 4;
            $scope.showDeleteButton = false;



            $scope.createRecord = function() {
                var data = $.param({
                    'name': $scope.name,
                    'email': $scope.email,
                });

                $http({
                    method: 'POST',
                    url: $config.base_url + 'frontPageController/create',
                    data: data,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                    }
                }).then(function(response) {
                    new PNotify({
                        title: 'Success',
                        text: 'New Record Added successfully',
                        type: 'success',
                        styling: 'bootstrap3',
                        width: '350px',
                        minHeight: '100px',
                        delay: 2000
                    });
                    $scope.name = '';
                    $scope.email = '';
                    $scope.getSubmittedData();
                    $('#addModal').modal('hide');
                }).catch(function(error) {
                    console.log('Error:', error);
                });
            };

            $scope.getSubmittedData = function() {
                var start = ($scope.currentPage - 1) * $scope.itemsPerPage;
                var end = start + $scope.itemsPerPage;

                $http({
                    method: 'GET',
                    url: $config.base_url + 'frontPageController/getData',
                    params: {
                        start: start,
                        end: end
                    }
                }).then(function(response) {
                    $scope.submittedData = response.data.data;
                    console.log($scope.submittedData);
                    if (response.data.total_records !== undefined) {
                        $scope.totalPages = Math.ceil(response.data.total_records / $scope.itemsPerPage);
                    } else {
                        console.error('total_records is undefined');
                    }
                }).catch(function(error) {
                    console.log('Error:', error);
                });
            }


            // Call the function to retrieve the submitted data on page load
            $scope.getSubmittedData();



            $scope.setPage = function(page) {
                $scope.currentPage = page;
                $scope.getSubmittedData();
            }

            $scope.openEditModal = function(record) {
                $scope.editIndex = $scope.submittedData.indexOf(record);
                $scope.id = record.id;
                $scope.editedName = record.name;
                $scope.editedEmail = record.email;
                $('#editModal').modal('show');
            }

            $scope.updateRecord = function() {
                var editedData = {
                    'id': $scope.id,
                    'name': $scope.editedName,
                    'email': $scope.editedEmail
                };
                var data = $.param(editedData);
                $http({
                    method: 'POST',
                    url: $config.base_url + 'frontPageController/update',
                    data: data,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                    }
                }).then(function(response) {
                    new PNotify({
                        title: 'Success',
                        text: 'Record updated successfully',
                        type: 'success',
                        styling: 'bootstrap3',
                        width: '350px',
                        minHeight: '100px',
                        delay: 2000
                    });
                    $scope.editedName = '';
                    $scope.editedEmail = '';
                    $scope.editIndex = -1;
                    $('#editModal').modal('hide');
                    $scope.getSubmittedData();
                }).catch(function(error) {
                    console.log('Error:', error);
                });
            }

            $scope.deleteRecord = function(record) {
                $("#deleteFolderModal").modal('show');
                $('#deleteFolderModal .yes').on('click', function(e) {
                    $("#deleteFolderModal").modal("hide");
                    var data = $.param({
                        'id': record.id
                    });
                    $http({
                        method: 'POST',
                        url: $config.base_url + 'frontPageController/delete',
                        data: data,
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                        }
                    }).then(function(response) {
                        new PNotify({
                            title: 'Success',
                            text: 'Record deleted successfully',
                            type: 'success',
                            styling: 'bootstrap3',
                            width: '350px',
                            minHeight: '100px',
                            delay: 2000
                        });
                        $scope.getSubmittedData();
                    }).catch(function(error) {
                        console.log('Error:', error);
                    });
                });
            };




            $scope.deleteSelected = function() {
                var selectedRecords = $scope.submittedData.filter(function(record) {
                    return record.checked;
                });

                if (selectedRecords.length > 0) {
                    var confirmation = confirm('Are you sure you want to delete the selected records?');
                    if (confirmation) {
                        var idsToDelete = selectedRecords.map(function(record) {
                            return record.id;
                        });

                        var data = $.param({
                            'ids': idsToDelete
                        });

                        $http({
                            method: 'POST',
                            url: $config.base_url + 'frontPageController/deleteSelected',
                            data: data,
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                            }
                        }).then(function(response) {
                            new PNotify({
                                title: 'Success',
                                text: 'Record deleted successfully',
                                type: 'success',
                                styling: 'bootstrap3',
                                width: '350px',
                                minHeight: '100px',
                                delay: 2000
                            });
                            $scope.getSubmittedData();
                            $scope.showDeleteButton = false;
                        }).catch(function(error) {
                            console.log('Error:', error);
                        });
                    }
                } else {
                    alert('No records selected');
                }
            };


            $scope.toggleAll = function() {
                var allChecked = $scope.submittedData.every(function(record) {
                    return record.checked;
                });

                $scope.submittedData.forEach(function(record) {
                    record.checked = !allChecked;
                });

                $scope.showDeleteButton = $scope.submittedData.some(function(record) {
                    return record.checked;
                });
            };


            $scope.$watch('submittedData', function() {
                $scope.showDeleteButton = $scope.submittedData.some(function(record) {
                    return record.checked;
                });
            }, true);




            $scope.search = function() {
                $scope.searchButtonClicked = true;
                $http({
                    method: 'GET',
                    url: $config.base_url + 'frontPageController/searchData',
                    params: {
                        query: $scope.searchQuery
                    }
                }).then(function(response) {
                    $scope.filteredData = response.data;
                }).catch(function(error) {
                    console.log('Error:', error);
                });
            }


            $scope.sortBy = function(key) {
                if ($scope.sortKey === key) {
                    $scope.reverse = !$scope.reverse;
                } else {
                    $scope.sortKey = key;
                    $scope.reverse = false;
                }
            }


            $scope.goToPageFn = function() {
                if ($scope.currentPage >= 1 && $scope.currentPage <= $scope.totalPages) {
                    $scope.getSubmittedData();
                } else {
                    // Disable the "Next" button if the entered page is invalid
                    $scope.currentPage = Math.min(Math.max($scope.currentPage, 1), $scope.totalPages);
                    new PNotify({
                        title: 'Error',
                        text: 'Invalid Page Number',
                        type: 'error',
                        styling: 'bootstrap3',
                        width: '350px',
                        minHeight: '100px',
                        delay: 2000
                    });
                }
            };

            $scope.downloadCSV = function(id) {
    $http({
        method: 'GET',
        url: $config.base_url + 'frontPageController/downloadData/' + id,
        responseType: 'arraybuffer', // Specify responseType as arraybuffer
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
        }
    }).then(function(response) {
        let blob = new Blob([response.data], { type: 'text/csv' });
        let link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = 'data.csv';
        link.click();
    }).catch(function(error) {
        console.log('Error:', error);
    });
};

        }]);
    </script>

</body>

</html>