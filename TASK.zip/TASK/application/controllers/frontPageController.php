<?php

class frontPageController  extends CI_Controller
{
    public function index()
    {
        $this->load->view('frontPage');
    }

    public function create()
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST');
        header('Access-Control-Allow-Headers: Content-Type');

        $data = array(
            'name' => $this->input->post('name'),
            'email' => $this->input->post('email')
        );

        $insert = $this->MyModel->insertRecord($data);

        if ($insert) {
            echo "data submitted";
        } else {
            echo "something went wrong";
        }
    }

    public function getData()
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST');
        header('Access-Control-Allow-Headers: Content-Type');

        $start = $this->input->get('start');
        $end = $this->input->get('end');

        $data = $this->MyModel->getRecords($start, $end);
        $total_records = $this->MyModel->getTotalRecords();

        $response = array(
            'data' => $data,
            'total_records' => $total_records
        );
        echo json_encode($response);
    }



    public function update()
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST');
        header('Access-Control-Allow-Headers: Content-Type');

        $data = array(
            'id' => $this->input->post('id'),
            'name' => $this->input->post('name'),
            'email' => $this->input->post('email')
        );

        $update = $this->MyModel->updateRecord($data);

        if ($update) {
            echo "record updated";
        } else {
            echo "something went wrong";
        }
    }

    public function delete()
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST');
        header('Access-Control-Allow-Headers: Content-Type');

        $data = array(
            'id' => $this->input->post('id'),
        );

        $delete = $this->MyModel->deleteRecord($data);

        if ($delete) {
            echo "record deleted";
        } else {
            echo "something went wrong";
        }
    }

    public function deleteSelected()
    {
        $ids = $this->input->post('ids');
        $this->db->where_in('id', $ids);
        $this->db->delete('crud');
        $response = array('message' => 'Selected records deleted');
        echo json_encode($response);
    }
    public function searchData()
    {
        $query = $this->input->get('query');
        $results = $this->MyModel->searchRecords($query);
        echo json_encode($results);
    }

    public function downloadData($id)
    {
        $record = $this->MyModel->getRecordById($id);
        
        if ($record) {
            $csvData = "Name,Email\n{$record['name']},{$record['email']}";
        
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename=data.csv');
    
            print_r($csvData);
        } else {
            echo "Record not found";
        }
    }
    
    
    
}
