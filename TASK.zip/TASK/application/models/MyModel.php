<?php
defined('BASEPATH') or exit('No direct script access allowed');

class MyModel extends CI_Model
{

    public function insertRecord($data)
    {
        $this->db->insert('crud', $data);
    }

    public function getRecords($start, $end)
    {
        $start = intval($start); // Convert to integer
        $end = intval($end);     // Convert to integer

        $this->db->select('*');
        $this->db->limit($end - $start, $start);
        $q = $this->db->get('crud');
        $results = $q->result_array();

        return $results;
    }

    public function getTotalRecords()
    {
        return $this->db->count_all('crud');
    }

    public function updateRecord($data)
    {
        $this->db->where('id', $data['id']);
        return $this->db->update('crud', $data);
    }

    public function deleteRecord($data)
    {
        $this->db->where('id', $data['id']);
        return $this->db->delete('crud');
    }

    public function addUser($userData)
    {
        $this->db->insert('signup', $userData);
        return $this->db->insert_id();
    }


    public function searchRecords($query)
    {
        $this->db->select('*');
        $this->db->like('name', $query);
        $q = $this->db->get('crud');
        $results = $q->result_array();

        return $results;
    }

    public function getRecordById($id)
    {
        $q = $this->db->get_where('crud', array('id' => $id), 1);
        return $q->row_array();
    }
}
